-- eventHandlers.lua
local eventHandlers = {}

function eventHandlers.initialize(car, ui)
    -- Обработчик событий клавиатуры
    local function onKeyEvent(event)
        if event.phase == "down" then
            if event.keyName == "up" then
                car.isAccelerating = true
                car.isReversing = false
            elseif event.keyName == "down" then
                car.isReversing = true
                car.isAccelerating = false
            elseif event.keyName == "space" then
                car.isHardBraking = true
            elseif event.keyName == "left" then
                car.isTurningLeft = true
            elseif event.keyName == "right" then
                car.isTurningRight = true
            elseif event.keyName == "q" then
                local currentTime = system.getTimer()
                if currentTime - car.lastQPressTime < car.qPressTimeThreshold then
                    car.qPressCount = car.qPressCount + 1
                else
                    car.qPressCount = 1
                end
                car.lastQPressTime = currentTime

                if car.qPressCount == 3 then
                    car.isEngineOn = true
                    car.qPressCount = 0
                    ui.engineStatusText.text = "Двигатель заведён! Можете ехать."
                    ui.engineStatusText:setFillColor(0, 1, 0)
                end
            elseif event.keyName == "b" then
                audio.play(ui.beeSound)
            elseif event.keyName == "f11" then
                ui.toggleFullscreen()
            end
        elseif event.phase == "up" then
            if event.keyName == "up" then
                car.isAccelerating = false
            elseif event.keyName == "down" then
                car.isReversing = false
            elseif event.keyName == "space" then
                car.isHardBraking = false
            elseif event.keyName == "left" then
                car.isTurningLeft = false
            elseif event.keyName == "right" then
                car.isTurningRight = false
            end
        end
        return true
    end

    -- Подключаем обработчик событий клавиатуры
    Runtime:addEventListener("key", onKeyEvent)

    -- Обработчик изменения размеров экрана
    local function onResize(event)
        local screenWidth = display.contentWidth
        local screenHeight = display.contentHeight
        ui.engineStatusText.x = screenWidth * 0.5
        ui.engineStatusText.y = screenHeight * 0.1
        ui.fullscreenText.x = screenWidth - 100
        ui.fullscreenText.y = 30
        car.image.x = screenWidth * 0.5
        car.image.y = screenHeight * 0.5
    end

    Runtime:addEventListener("resize", onResize)
end

return eventHandlers