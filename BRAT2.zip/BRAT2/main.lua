-- main.lua
local carModule = require("car")  -- Подключаем модуль машины
local missionModule = require("mission")  -- Подключаем модуль миссий
local trashModule = require("trash")  -- Подключаем модуль мусора
local uiModule = require("ui")  -- Подключаем модуль интерфейса
local eventHandlers = require("eventHandlers")  -- Подключаем модуль обработчиков событий
local moneyModule = require("money")  -- Подключаем модуль денег
local mapModule = require("map")  -- Подключаем модуль карты
local npcModule = require("npc")  -- Подключаем модуль NPC
local radioModule = require("radio")  -- Подключаем модуль радио

local moneyModule = require("money")
-- Инициализация игры
local function initializeGame()
    carModule.initialize()
    missionModule.initialize(carModule)  -- Передаем модуль машины в миссию
    trashModule.initialize()
    uiModule.initialize()
    eventHandlers.initialize(carModule, uiModule, radioModule)  -- Передаем модули в обработчик событий
    moneyModule.initialize()  -- Инициализируем деньги
    mapModule.initialize()  -- Инициализируем карту
    npcModule.initialize(carModule, mapModule)  -- Передаем carModule и mapModule в NPC

    -- Добавляем карту в камеру
    carModule.camera:insert(mapModule.tileGroup)

    -- Добавляем машину в камеру (после карты, чтобы она была поверх)
    carModule.camera:insert(carModule.image)
    -- Инициализируем джойстик
   
    -- Добавляем NPC в камеру
    carModule.camera:insert(npcModule.image)

    -- Подключаем функцию обновления машины к событию enterFrame
    Runtime:addEventListener("enterFrame", carModule.update)

    -- Подключаем функцию обновления NPC к событию enterFrame
    Runtime:addEventListener("enterFrame", npcModule.moveToTarget)
end

-- Запуск игры
initializeGame()