-- mission.lua
local mission = {}
local money = require("money")  -- Подключаем модуль денег

-- Получаем размеры экрана и масштабирующий коэффициент
local screenWidth, screenHeight = display.contentWidth, display.contentHeight
local scaleFactor = math.min(screenWidth / 1080, screenHeight / 1920)

-- Настройки миссий
mission.missions = {
    {
        x = 2 * 128 + 150,  -- Координаты первой миссии
        y = 2 * 128 - 150,
        reward = 80,       -- Награда за первую миссию
        completed = false   -- Статус выполнения
    },
    {
        x = 5 * 128 + 150,  -- Координаты второй миссии
        y = 5 * 128 - 150,
        reward = 200,       -- Награда за вторую миссию
        completed = false   -- Статус выполнения
    }
}

-- Текущая миссия
mission.currentMissionIndex = 1

-- Инициализация миссии
function mission.initialize(car)
    mission.car = car  -- Сохраняем объект машины

    -- Запускаем первую миссию
    mission.startMission(mission.currentMissionIndex)
end

-- Запуск миссии по индексу
function mission.startMission(index)
    local missionData = mission.missions[index]

    -- Создаем цель миссии
    mission.target = display.newCircle(0, 0, 50)  -- Уменьшим радиус для точности
    mission.target:setFillColor(1, 0, 0)  -- Красный круг
    mission.target.x = missionData.x
    mission.target.y = missionData.y
    physics.addBody(mission.target, { isSensor = true })  -- Делаем цель сенсором

    -- Добавляем цель в камеру машины
    if mission.car.camera then
        mission.car.camera:insert(mission.target)
    end

    -- Убедимся, что цель отображается поверх других объектов
    mission.target:toFront()

    -- Отладочный вывод координат метки
    print("Миссия " .. index .. " создана: x =", mission.target.x, "y =", mission.target.y)

    -- Стрелка-указатель
    mission.arrow = display.newImage("arrow.png", screenWidth * 0.7, 50)
    mission.arrow.width = 250 * scaleFactor
    mission.arrow.height = 250 * scaleFactor
    mission.arrow:toFront()

    -- Подключаем функции обновления стрелки и проверки миссии
    Runtime:addEventListener("enterFrame", mission.updateArrow)
    Runtime:addEventListener("enterFrame", mission.checkMissionComplete)
end

-- Обновление направления стрелки
function mission.updateArrow()
    -- Получаем координаты метки относительно камеры
    local targetX = mission.target.x - mission.car.camera.x
    local targetY = mission.target.y - mission.car.camera.y

    -- Получаем координаты машины относительно камеры
    local carX = mission.car.image.x - mission.car.camera.x
    local carY = mission.car.image.y - mission.car.camera.y

    -- Вычисляем разницу между координатами
    local dx = targetX - carX
    local dy = targetY - carY

    -- Вычисляем угол и поворачиваем стрелку
    local angle = math.atan2(dy, dx) * (180 / math.pi)
    mission.arrow.rotation = angle

    -- Позиция стрелки на экране
    mission.arrow.x = screenWidth * 0.6
    mission.arrow.y = -29
end

-- Проверка завершения миссии
function mission.checkMissionComplete()
    -- Получаем координаты метки относительно камеры
    local targetX = mission.target.x - mission.car.camera.x
    local targetY = mission.target.y - mission.car.camera.y

    -- Получаем координаты машины относительно камеры
    local carX = mission.car.image.x - mission.car.camera.x
    local carY = mission.car.image.y - mission.car.camera.y

    -- Вычисляем расстояние между машиной и целью
    local dx = targetX - carX
    local dy = targetY - carY
    local distance = math.sqrt(dx * dx + dy * dy)



    -- Если машина близко к цели, миссия завершена
    if distance < 70 then  -- Увеличим радиус для удобства
        local missionData = mission.missions[mission.currentMissionIndex]

        -- Награда за выполнение миссии
        money.add(missionData.reward)  -- Добавляем деньги
        print("Миссия " .. mission.currentMissionIndex .. " выполнена! Получено денег:", missionData.reward)

        -- Удаляем цель и стрелку
        mission.target:removeSelf()  -- Удаляем цель
        mission.arrow:removeSelf()  -- Удаляем стрелку

        -- Отключаем слушатели
        Runtime:removeEventListener("enterFrame", mission.updateArrow)
        Runtime:removeEventListener("enterFrame", mission.checkMissionComplete)

        -- Помечаем миссию как выполненную
        missionData.completed = true

        -- Запускаем следующую миссию, если она есть
        mission.currentMissionIndex = mission.currentMissionIndex + 1
        if mission.missions[mission.currentMissionIndex] then
            mission.startMission(mission.currentMissionIndex)
        else
            print("Все миссии выполнены!")
        end
    end
end

return mission