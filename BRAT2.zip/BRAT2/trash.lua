-- trash.lua
local trash = {}
local physics = require("physics")

function trash.initialize()
    trash.trashList = {}
    trash.trashImage = "trash.png"
    trash.trashSpawnDistance = 1
    trash.trashLifetime = 3000
    trash.trashSpawnChance = 0.9
end

function trash.createTrash(x, y)
    local trashPiece = display.newImage(trash.trashImage, x, y)
    trashPiece.width = 5000
    trashPiece.height = 5000
    physics.addBody(trashPiece, { density = 0.1, friction = 0.3, bounce = 0.5 })
    table.insert(trash.trashList, trashPiece)

    timer.performWithDelay(trash.trashLifetime, function()
        display.remove(trashPiece)
        for i = #trash.trashList, 1, -1 do
            if trash.trashList[i] == trashPiece then
                table.remove(trash.trashList, i)
                break
            end
        end
    end)
end

function trash.updateTrash(cameraX, cameraY)
    for i = #trash.trashList, 1, -1 do
        local trashPiece = trash.trashList[i]
        if trashPiece and trashPiece.x then
            trashPiece.x = trashPiece.x - cameraX + screenWidth * 0.5
            trashPiece.y = trashPiece.y - cameraY + screenHeight * 0.5
        end
    end
end

function trash.scatterTrash(carX, carY)
    for i = #trash.trashList, 1, -1 do
        local trashPiece = trash.trashList[i]
        if trashPiece and trashPiece.x then
            local dx = trashPiece.x - carX
            local dy = trashPiece.y - carY
            local distance = math.sqrt(dx * dx + dy * dy)

            if distance < 100 then
                local forceX = (math.random() - 0.5) * 500
                local forceY = (math.random() - 0.5) * 500
                trashPiece:applyForce(forceX, forceY, trashPiece.x, trashPiece.y)
            end
        end
    end
end

return trash