-- npc.lua
local npc = {}
local physics = require("physics")

-- Инициализация NPC
function npc.initialize(carModule, map)
    local screenWidth, screenHeight = display.contentWidth, display.contentHeight
    local scaleFactor = math.min(screenWidth / 1080, screenHeight / 1920)

    -- Создаем изображение NPC
    npc.image = display.newImage("npc.png", screenWidth * 0.2, screenHeight * 0.2)
    if not npc.image then
        print("Ошибка: Не удалось загрузить изображение NPC!")
        return
    end

    npc.image.width = 250 * scaleFactor
    npc.image.height = 200 * scaleFactor
    physics.addBody(npc.image, { density = 1, friction = 0.3, bounce = 0.2 })
    npc.image.rotation = 0

    -- Параметры NPC
    npc.speed = 200 * scaleFactor  -- Скорость NPC
    npc.map = map  -- Передаем карту в NPC
    npc.targetX, npc.targetY = npc.image.x, npc.image.y  -- Целевая позиция
    npc.isMoving = false  -- Флаг, указывающий, движется ли NPC

    -- Добавляем NPC в камеру
    carModule.camera:insert(npc.image)

    -- Ищем первую цель
    npc.findNewTarget()
end

-- Функция для поиска новой цели
function npc.findNewTarget()
    local screenWidth = display.contentWidth
    local screenHeight = display.contentHeight

    -- Генерация случайной позиции
    local newTargetX = math.random(0, screenWidth)
    local newTargetY = math.random(0, screenHeight)

    -- Проверка, что цель не находится на воде или препятствии
    local tileCol = math.floor(newTargetX / npc.map.tileSize) + 1
    local tileRow = math.floor(newTargetY / npc.map.tileSize) + 1

    if tileRow >= 1 and tileRow <= #npc.map.mapData and tileCol >= 1 and tileCol <= #npc.map.mapData[1] then
        local tileType = npc.map.mapData[tileRow][tileCol]
        if tileType == 0 then  -- Только трава
            npc.targetX = newTargetX
            npc.targetY = newTargetY
            npc.isMoving = true
        end
    end
end

-- Функция для движения к цели
function npc.moveToTarget(event)
    if npc.isMoving then
        local dx = npc.targetX - npc.image.x
        local dy = npc.targetY - npc.image.y
        local distance = math.sqrt(dx * dx + dy * dy)

        if distance > 5 then  -- Если NPC не достиг цели
            -- Вычисляем направление
            local angle = math.atan2(dy, dx)
            local vx = math.cos(angle) * npc.speed
            local vy = math.sin(angle) * npc.speed

            -- Двигаем NPC
            npc.image:setLinearVelocity(vx, vy)
        else
            -- Останавливаем NPC
            npc.image:setLinearVelocity(0, 0)
            npc.isMoving = false
            npc.findNewTarget()  -- Ищем новую цель
        end
    end
end

return npc