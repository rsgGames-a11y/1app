-- ui.lua
local ui = {}
local screenWidth, screenHeight = display.contentWidth, display.contentHeight
local scaleFactor = math.min(screenWidth / 1080, screenHeight / 1920)

function ui.initialize()
    ui.isFullscreen = false

    ui.engineStatusText = display.newText({
        text = "Двигатель выключен. Нажмите 'q' три раза, чтобы завести.",
        x = screenWidth * 0.5,
        y = screenHeight * 0.1,
        fontSize = 50 * scaleFactor,
        align = "center"
    })
    ui.engineStatusText:setFillColor(1, 1, 1)

    ui.fullscreenText = display.newText({
        text = "Режим: Оконный",
        x = screenWidth - 100,
        y = 30,
        fontSize = 16,
        align = "right"
    })
    ui.fullscreenText:setFillColor(1, 1, 1)

    ui.beeSound = audio.loadSound("bi.mp3")
end

function ui.toggleFullscreen()
    ui.isFullscreen = not ui.isFullscreen
    if ui.isFullscreen then
        native.setProperty("windowMode", "fullscreen")
    else
        native.setProperty("windowMode", "normal")
    end
    ui.updateFullscreenText()
end

function ui.updateFullscreenText()
    ui.fullscreenText.text = ui.isFullscreen and "Режим: Полный экран" or "Режим: Оконный"
end

function ui.onKeyEvent(event)
    if event.phase == "down" then
        if event.keyName == "f11" then
            ui.toggleFullscreen()
        elseif event.keyName == "b" then
            audio.play(ui.beeSound)
        end
    end
end

return ui