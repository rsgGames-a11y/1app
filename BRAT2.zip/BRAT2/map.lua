-- map.lua
local map = {}

-- Размер тайла (в пикселях)
map.tileSize = 128  -- Делаем tileSize доступным извне

-- Тайлы (каждому числу соответствует свой тайл)
local tiles = {
    [0] = "grass.png",  -- Трава
    [2] = "house.png",  -- Дом
    [3] = "water.png",  -- Вода
}

-- Карта (двумерный массив)
map.mapData = {  -- Делаем mapData доступным извне
    {3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3},
    {3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3},
    {3, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 3, 3},
    {3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3},
    {3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3},
    {3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3},
    {3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3},
    {3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3},
    {3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3},
    {3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3},
    {3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3},
    {3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3 ,3},
    {3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3 ,3},
    {3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3 ,3},
    {3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3 ,3},
    {3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3 ,3},
    {3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3 ,3},
    {3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3 ,3},
    {3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3 ,3},
    {3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3 ,3},
}

-- Инициализация карты
function map.initialize()
    -- Группа для хранения всех тайлов
    map.tileGroup = display.newGroup()

    -- Группа для травы
    local groundGroup = display.newGroup()
    map.tileGroup:insert(groundGroup)

    -- Группа для домов
    local houseGroup = display.newGroup()
    map.tileGroup:insert(houseGroup)

    -- Группа для воды
    local waterGroup = display.newGroup()
    map.tileGroup:insert(waterGroup)

    -- Проходим по всем строкам и столбцам карты
    for row = 1, #map.mapData do
        for col = 1, #map.mapData[row] do
            -- Получаем тип тайла
            local tileType = map.mapData[row][col]

            -- Создаем спрайт для тайла
            local tile = display.newImageRect(map.tileGroup, tiles[tileType], map.tileSize, map.tileSize)

            -- Позиционируем тайл
            tile.x = (col - 1) * map.tileSize
            tile.y = (row - 1) * map.tileSize

            -- Добавляем тайл в соответствующую группу
            if tileType == 2 then  -- Дом
                tile.width = map.tileSize * 2  -- Увеличиваем ширину в 2 раза
                tile.height = map.tileSize * 2  -- Увеличиваем высоту в 2 раза
                physics.addBody(tile, { density = 0, friction = 0.5, bounce = 0, isSensor = false })  -- Статическое тело
                tile.bodyType = "static"  -- Явно указываем, что это статическое тело
                houseGroup:insert(tile)  -- Добавляем дом в группу домов
            elseif tileType == 3 then  -- Вода
                physics.addBody(tile, { isSensor = true })  -- Делаем воду сенсором
                tile.type = "water"  -- Добавляем тип для обработки столкновений
                waterGroup:insert(tile)  -- Добавляем воду в группу воды
            else
                groundGroup:insert(tile)  -- Добавляем траву в группу земли
            end
        end
    end
end

return map