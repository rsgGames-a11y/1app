-- money.lua
local money = {}
local json = require("json")  -- Для работы с JSON (сохранение и загрузка данных)

-- Настройки
local saveFilePath = system.pathForFile("moneyData.json", system.DocumentsDirectory)  -- Путь к файлу сохранения
local defaultMoney = 100  -- Начальное количество денег

-- Инициализация
function money.initialize()
    money.balance = defaultMoney
    money.load()  -- Загружаем сохраненные данные
end

-- Получить текущий баланс
function money.getBalance()
    return money.balance
end

-- Добавить деньги
function money.add(amount)
    money.balance = money.balance + amount
    money.save()  -- Сохраняем изменения
end

-- Списать деньги
function money.subtract(amount)
    if money.balance >= amount then
        money.balance = money.balance - amount
        money.save()  -- Сохраняем изменения
        return true  -- Успешно
    else
        return false  -- Недостаточно средств
    end
end

-- Сбросить деньги к значению по умолчанию
function money.reset()
    money.balance = defaultMoney
    money.save()  -- Сохраняем изменения
    print("Деньги сброшены до значения по умолчанию: " .. defaultMoney)
end

-- Сохранить данные в файл
function money.save()
    local data = {
        balance = money.balance
    }
    local file = io.open(saveFilePath, "w")  -- Открываем файл для записи
    if file then
        file:write(json.encode(data))  -- Записываем данные в формате JSON
        io.close(file)
    else
        print("Ошибка: Не удалось сохранить данные.")
    end
end

-- Загрузить данные из файла
function money.load()
    local file = io.open(saveFilePath, "r")  -- Открываем файл для чтения
    if file then
        local contents = file:read("*a")  -- Читаем весь файл
        local data = json.decode(contents)  -- Декодируем JSON
        io.close(file)
        if data and data.balance then
            money.balance = data.balance  -- Загружаем баланс
        else
            money.balance = defaultMoney  -- Используем значение по умолчанию
        end
    else
        money.balance = defaultMoney  -- Используем значение по умолчанию
    end
end

return money