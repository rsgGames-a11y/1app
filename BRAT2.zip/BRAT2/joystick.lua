-- joystick.lua
local joystick = {}

function joystick.initialize(car)
    local joystickRadius = 50
    local joystickBackgroundRadius = 80
    local screenWidth, screenHeight = display.contentWidth, display.contentHeight

    -- Создаем фон джойстика
    joystick.background = display.newCircle(screenWidth * 0.1, screenHeight * 0.8, joystickBackgroundRadius)
    joystick.background:setFillColor(0.5, 0.5, 0.5, 0.5)  -- Полупрозрачный серый цвет

    -- Создаем сам джойстик
    joystick.thumb = display.newCircle(screenWidth * 0.1, screenHeight * 0.8, joystickRadius)
    joystick.thumb:setFillColor(0.8, 0.8, 0.8, 0.8)  -- Полупрозрачный белый цвет

    -- Переменные для управления
    local isJoystickActive = false
    local joystickCenterX, joystickCenterY = joystick.thumb.x, joystick.thumb.y

    -- Обработчик касаний
    local function onTouch(event)
        local phase = event.phase
        local x, y = event.x, event.y

        if phase == "began" then
            -- Проверяем, касается ли палец джойстика
            if math.sqrt((x - joystickCenterX)^2 + (y - joystickCenterY)^2) <= joystickBackgroundRadius then
                isJoystickActive = true
            end
        elseif phase == "moved" and isJoystickActive then
            -- Перемещаем джойстик в пределах фона
            local dx = x - joystickCenterX
            local dy = y - joystickCenterY
            local distance = math.sqrt(dx^2 + dy^2)

            if distance > joystickBackgroundRadius then
                dx = dx * (joystickBackgroundRadius / distance)
                dy = dy * (joystickBackgroundRadius / distance)
            end

            joystick.thumb.x = joystickCenterX + dx
            joystick.thumb.y = joystickCenterY + dy

            -- Управление машиной
            local angle = math.atan2(dy, dx)
            local speed = distance / joystickBackgroundRadius

            -- Ускорение и поворот
            car.isAccelerating = true
            car.speed = car.maxSpeed * speed

            -- Поворот
            car.image.rotation = math.deg(angle)
        elseif phase == "ended" or phase == "cancelled" then
            -- Возвращаем джойстик в центр
            joystick.thumb.x = joystickCenterX
            joystick.thumb.y = joystickCenterY
            isJoystickActive = false

            -- Останавливаем машину
            car.isAccelerating = false
            car.speed = 0
        end
    end

    -- Добавляем обработчик касаний
    Runtime:addEventListener("touch", onTouch)
end

return joystick