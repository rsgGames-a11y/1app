-- player.lua
local player = {}

local screenWidth, screenHeight = display.contentWidth, display.contentHeight
local scaleFactor = math.min(screenWidth / 1080, screenHeight / 1920)

-- Камера персонажа
player.camera = display.newGroup()  -- Создаем группу для камеры персонажа

function player.initialize()
    -- Загружаем изображение персонажа
    player.image = display.newImage("player.png", screenWidth * 0.5, screenHeight * 0.5)
    player.image.width = 100 * scaleFactor
    player.image.height = 100 * scaleFactor
    physics.addBody(player.image, { density = 1, friction = 0.3, bounce = 0.2 })
    player.image.rotation = 0

    -- Параметры персонажа
    player.speed = 500 * scaleFactor
    player.isMoving = false
    player.isPlayerActive = false  -- По умолчанию персонаж не активен

    -- Добавляем персонажа в камеру
    player.camera:insert(player.image)
    player.image:toFront()  -- Персонаж отображается поверх всех объектов

    -- Скрываем персонажа по умолчанию
    player.image.isVisible = false
end

-- Обновление камеры персонажа
function player.updateCamera()
    player.camera.x = -player.image.x + screenWidth * 0.5
    player.camera.y = -player.image.y + screenHeight * 0.5
end

-- Обновление персонажа
function player.update(event)
    if player.isPlayerActive then
        local vx, vy = 0, 0

        if player.isMoving then
            local radians = math.rad(player.image.rotation)
            vx = math.cos(radians) * player.speed
            vy = math.sin(radians) * player.speed
        end

        player.image:setLinearVelocity(vx, vy)

        -- Обновление камеры персонажа
        player.updateCamera()
    end
end

-- Управление персонажем
function player.move(direction)
    if direction == "up" then
        player.isMoving = true
    elseif direction == "down" then
        player.isMoving = false
    elseif direction == "left" then
        player.image.rotation = player.image.rotation - 5
    elseif direction == "right" then
        player.image.rotation = player.image.rotation + 5
    end
end

-- Переключение между машиной и персонажем
function player.toggleControl(car)
    if player.isPlayerActive then
        -- Переключаемся на машину
        player.isPlayerActive = false
        car.isEngineOn = true  -- Включаем управление машиной
        player.image.isVisible = false  -- Скрываем персонажа
        car.camera.isVisible = true  -- Показываем камеру машины
    else
        -- Переключаемся на персонажа
        player.isPlayerActive = true
        car.isEngineOn = false  -- Отключаем управление машиной
        player.image.isVisible = true  -- Показываем персонажа
        car.camera.isVisible = false  -- Скрываем камеру машины

        -- Устанавливаем позицию персонажа рядом с машиной
        player.image.x = car.image.x + 100
        player.image.y = car.image.y
    end
end

return player