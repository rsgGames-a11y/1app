-- radio.lua
local radio = {}

-- Загружаем аудиофайл для радио
local radioSound = audio.loadStream("radio.mp3")  -- Убедитесь, что файл radio.mp3 находится в папке ресурсов

-- Переменная для отслеживания состояния радио
radio.isPlaying = false

-- Функция для включения радио
function radio.turnOn()
    if not radio.isPlaying then
        radio.channel = audio.play(radioSound, { loops = -1 })  -- Зацикливаем воспроизведение
        radio.isPlaying = true
        print("Радио включено!")
    end
end

-- Функция для выключения радио
function radio.turnOff()
    if radio.isPlaying then
        audio.stop(radio.channel)  -- Останавливаем воспроизведение
        radio.isPlaying = false
        print("Радио выключено!")
    end
end

-- Обработчик событий клавиатуры
local function onKeyEvent(event)
    if event.phase == "down" then
        if event.keyName == "f" then
            radio.turnOn()  -- Включаем радио при нажатии на F
        elseif event.keyName == "d" then
            radio.turnOff()  -- Выключаем радио при нажатии на D
        end
    end
    return false  -- Возвращаем false, чтобы событие не распространялось дальше
end

-- Добавляем слушатель событий клавиатуры
Runtime:addEventListener("key", onKeyEvent)

return radio