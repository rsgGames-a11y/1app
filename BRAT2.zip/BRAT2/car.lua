-- car.lua
local physics = require("physics")
physics.start()
physics.setGravity(0, 0)

local car = {}
local screenWidth, screenHeight = display.contentWidth, display.contentHeight
local scaleFactor = math.min(screenWidth / 1080, screenHeight / 1920)

-- Камера
car.camera = display.newGroup()  -- Создаем группу для камеры

function car.initialize()
    -- Загружаем изображение машины
    car.image = display.newImage("car.png", screenWidth * 0.5, screenHeight * 0.5)
    car.image.width = 500 * scaleFactor
    car.image.height = 250 * scaleFactor
    physics.addBody(car.image, { density = 1, friction = 0.3, bounce = 0.2 })  -- Динамическое тело машины
    car.image.rotation = 0

    -- Параметры машины
    car.maxSpeed = 2000 * scaleFactor
    car.maxReverseSpeed = -500 * scaleFactor
    car.acceleration = 10 * scaleFactor
    car.deceleration = 10 * scaleFactor
    car.hardBrakingDeceleration = 30 * scaleFactor
    car.turnSpeed = 2
    car.driftFactor = 0.95

    -- Переменные для управления
    car.speed = 0
    car.isAccelerating = false
    car.isBraking = false
    car.isHardBraking = false
    car.isTurningLeft = false
    car.isTurningRight = false
    car.isEngineOn = false
    car.isReversing = false

    -- Переменные для тройного нажатия
    car.qPressCount = 0
    car.lastQPressTime = 0
    car.qPressTimeThreshold = 500

    -- Добавляем машину в камеру
    car.camera:insert(car.image)
    car.image:toFront()  -- Машина отображается поверх всех объектов
end

-- Обновление камеры
function car.updateCamera()
    car.camera.x = -car.image.x + screenWidth * 0.5
    car.camera.y = -car.image.y + screenHeight * 0.5
end

-- Обновление машины
function car.update(event)
    if car.isEngineOn then
        -- Ускорение 
        if car.isAccelerating then
            car.speed = car.speed + car.acceleration
            if car.speed > car.maxSpeed then
                car.speed = car.maxSpeed
            end
        elseif car.isReversing then
            car.speed = car.speed - car.acceleration
            if car.speed < car.maxReverseSpeed then
                car.speed = car.maxReverseSpeed
            end
        elseif car.isHardBraking then
            car.speed = car.speed - car.hardBrakingDeceleration
            if car.speed < 0 then
                car.speed = 0
            end
        elseif car.isBraking then
            car.speed = car.speed - car.deceleration
            if car.speed < 0 then
                car.speed = 0
            end
        else
            car.speed = car.speed * car.driftFactor
        end

        -- Поворот (только при движении)
        if car.speed ~= 0 then
            if car.isTurningLeft then
                car.image.rotation = car.image.rotation - car.turnSpeed * (car.speed / car.maxSpeed)
            elseif car.isTurningRight then
                car.image.rotation = car.image.rotation + car.turnSpeed * (car.speed / car.maxSpeed)
            end
        end

        -- Движение вперед или назад
        local radians = math.rad(car.image.rotation)
        local vx = math.cos(radians) * car.speed
        local vy = math.sin(radians) * car.speed
        car.image:setLinearVelocity(vx, vy)

        -- Обновление камеры
        car.updateCamera()
    end
end

-- Обработка столкновений
local function onCollision(event)
    if event.phase == "began" then
        local obj1 = event.object1
        local obj2 = event.object2

        -- Если машина сталкивается с водой
        if (obj1 == car.image and obj2.type == "water") or (obj2 == car.image and obj1.type == "water") then
            print("Машина в воде!")
            car.speed = 0  -- Останавливаем машину
            car.image:setLinearVelocity(0, 0)  -- Сбрасываем скорость
        end
    end
end

-- Добавляем слушатель столкновений
Runtime:addEventListener("collision", onCollision)

return car